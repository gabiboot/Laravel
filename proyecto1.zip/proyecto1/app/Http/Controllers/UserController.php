<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    //funcion para controlar la ruta
    Public function index()
    {
        $users = User::all();
        return view('index', compact('users'));

    }
}
