<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Note extends Model
{
    use HasFactory;

    protected $table = "notes";//automatico

    protected $fillable =["title", // campos que quiero que se modifiquen
"description",
"deadline"];
    protected $guarded;//lo contrario a lo anterior
    protected $casts = [
        ];//castearlos, 
    protected $hidden; // proteger, elementos que mantener oicukltos
}
