

<?php $__env->startSection('title','contact'); ?>
<?php $__env->startSection('content'); ?>
<h1>contact</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gmoya\OneDrive\Escritorio\laravel\proyecto1\resources\views/contact.blade.php ENDPATH**/ ?>