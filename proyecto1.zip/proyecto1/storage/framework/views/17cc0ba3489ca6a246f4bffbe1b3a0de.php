

<?php $__env->startSection('title','Inicio'); ?>
<?php $__env->startSection('content'); ?>
<h1>Index</h1>
<p>Lista de usuarios: 

<?php if($users.empty($users)): ?>
<h3 style="color: red;">Lista Vacia</h3>


<?php else: ?>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($user -> name); ?> </li>
<li><?php echo e($user -> email); ?> </li>
<li><?php echo e($user -> password); ?> </li>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

<?php endif; ?>
<ul>

</ul>
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gmoya\OneDrive\Escritorio\laravel\proyecto1\resources\views/index.blade.php ENDPATH**/ ?>