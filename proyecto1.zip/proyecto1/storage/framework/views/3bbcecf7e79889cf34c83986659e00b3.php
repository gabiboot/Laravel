

<?php $__env->startSection('title','Services'); ?>

<?php $__env->startSection('content'); ?>
         <h1>Services</h1>
         <?php $__env->startComponent('_components.cards'); ?>
             <?php $__env->slot('title', 'Service 1'); ?>
             <?php $__env->slot('content', 'lorem ipsum dolor seraimet.'); ?>
             
             <?php echo $__env->renderComponent(); ?>

             <?php $__env->startComponent('_components.cards'); ?>
             <?php $__env->slot('title', 'Service 2'); ?>
             <?php $__env->slot('content', 'lorem ipsum dolor seraimet. 2'); ?>
            

         <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\gmoya\OneDrive\Escritorio\laravel\proyecto1\resources\views/services.blade.php ENDPATH**/ ?>