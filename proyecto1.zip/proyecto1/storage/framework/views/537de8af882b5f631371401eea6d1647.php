<div style=" border: 1px solid pink; border-radius: 8px; padding: 10px; margin 5px;">
    <h3><?php echo e($title); ?></h3>
    <img src=" <?php echo e(asset('assets/img/reloj.jpg')); ?>" alt="reloj" whidth= "120">

    <p><?php echo e($content); ?></p>
    

</div><?php /**PATH C:\Users\gmoya\OneDrive\Escritorio\laravel\proyecto1\resources\views/_components/cards.blade.php ENDPATH**/ ?>