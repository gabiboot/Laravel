
<header>
     <nav>
        <ul>
         <li> <a href='<?php echo e(route('index')); ?>'> Inicio </a></li>
         <li> <a href='<?php echo e(route('services')); ?>'> Services</a></li>
         <li> <a href='<?php echo e(route('about')); ?>'> About</a></li>
        <li> <a href='<?php echo e(route('contact')); ?>'> Contact</a></li>
        </ul>
    </nav>
</header>

</body>
</html><?php /**PATH C:\Users\gmoya\OneDrive\Escritorio\laravel\proyecto1\resources\views/layouts/_partials/menu.blade.php ENDPATH**/ ?>