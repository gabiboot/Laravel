<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
/*
Genero las rutas para acceder con metodos estaticos de la clase ::

Route::view(); pinta directamente la vista sin necesidad del controlador, sin datos, un atajo

Route::get();
Route::post();
Route::put();
Route::delete();
Route::patch('/miruta/', ControladorDeLaRuta);

siempre 2 valores: 1- ruta y 2 controlador
siempre la ruta parte desde resources views
le podemos asociar nombre a las rutas -> name('welcome');

*/

/*Route::view('/index', 'index')->name('index'); 
Route::view('/about', 'about')->name('about');
Route::view('/services', 'services')->name('services'); 
Route::view('/contact', 'contact')->name('contact');
*/
//parametros vinculados a la ruta que clase de controlador y que funcion tiene que llamar
Route::get('/',[UserController::class, 'index'])->name('user.index');