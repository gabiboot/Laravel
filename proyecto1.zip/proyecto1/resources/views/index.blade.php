@extends ('layouts.landing')

@section ('title','Inicio')
@section('content')
<h1>Index</h1>
<p>Lista de usuarios: 

@if ($users.empty($users))
<h3 style="color: red;">Lista Vacia</h3>


@else
@foreach ( $users as $user )
<li>{{$user -> name}} </li>
<li>{{$user -> email}} </li>
<li>{{$user -> password}} </li>


@endforeach
    

@endif
<ul>

</ul>
</p>
@endsection