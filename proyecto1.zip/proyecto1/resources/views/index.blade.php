@extends ('layouts.landing')

@section ('title','Inicio')
@section('content')
<h1>Index</h1>
@endsection