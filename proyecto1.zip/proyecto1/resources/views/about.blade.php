@extends ('layouts.landing')

@section ('title','about')

@section('content')
<h1>About</h1>
@endsection