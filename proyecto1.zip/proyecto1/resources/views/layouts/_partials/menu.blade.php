
<header>
     <nav>
        <ul>
         <li> <a href='{{route('index')}}'> Inicio </a></li>
         <li> <a href='{{route('about')}}'> About</a></li>
        <li> <a href='{{route('contact')}}'> Contact</a></li>
        </ul>
    </nav>
</header>

</body>
</html>