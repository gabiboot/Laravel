@extends ('layouts.landing')

@section ('title','Services')

@section('content')
         <h1>Services</h1>
         @component('_components.cards')
             @slot('title', 'Service 1')
             @slot('content', 'lorem ipsum dolor seraimet.')
             
             @endcomponent

             @component('_components.cards')
             @slot('title', 'Service 2')
             @slot('content', 'lorem ipsum dolor seraimet. 2')
            

         @endcomponent
@endsection