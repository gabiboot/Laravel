@extends ('layouts.landing')

@section ('title','contact')
@section('content')
<h1>contact</h1>
@endsection