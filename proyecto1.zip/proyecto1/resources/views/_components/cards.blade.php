<div style=" border: 1px solid pink; border-radius: 8px; padding: 10px; margin 5px;">
    <h3>{{$title}}</h3>
    <img src=" {{asset('assets/img/reloj.jpg') }}" alt="reloj" whidth= "120">

    <p>{{$content}}</p>
    

</div>